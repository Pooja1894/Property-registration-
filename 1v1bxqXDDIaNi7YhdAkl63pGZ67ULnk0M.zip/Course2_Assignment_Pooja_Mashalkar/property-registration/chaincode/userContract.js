'use strict';

const { Contract } = require('fabric-contract-api');

class UserContract extends Contract {
    constructor() {
        //name of this smart contract
        super('regnet.user');
    }

    //this method will be triggered when the smart contract is deployed.
    //helps to verify if the smart contract is deployed successfully.
    async instantiate(ctx) {
        console.log("UserContract is deployed successfully.");
    }


    // Initiator: It will be the user. 
    // Output: A ‘Request’ asset on the ledger will be the output. 
    // Use case: This transaction is called by the user to request the registrar to
    //  register them on the property-registration-network.     
    async requestNewUser(ctx, name, emailId, phoneNumber, socialSecurityNumber) {
        const requestedUserKey = ctx.stub.createCompositeKey('regnet.requested', [name, socialSecurityNumber]);

        const requestedUserObject = {
            doctype: 'request',
            name: name,
            emailId: emailId,
            phoneNumber: phoneNumber,
            socialSecurityNumber: socialSecurityNumber,
            createdAt: ctx.stub.getTxTimestamp(),
            status: "new"
        }
        // add user in DB
        await ctx.stub.putState(requestedUserKey, Buffer.from(JSON.stringify(requestedUserObject)));

        return requestedUserObject;
    }


    // Initiator: It will be either the user or the registrar. 
    // Use case: This function should be defined to view the current state of any user.
    async viewUser(ctx, name, ssn) {
        const userKey = ctx.stub.createCompositeKey('regnet.user', [name, ssn]);
        const userBuffer = await ctx.stub.getState(userKey);
        // get the user data fron ledger
        if (userBuffer) {
            return JSON.parse(userBuffer.toString());
        } else {
            return "User with key=" + userKey + " does not exist"
        }
    }


    // Initiator: It will be the user. 
    // Use case: A user initiates this transaction to recharge their account with “upgradCoins.”    
    async rechargeAccount(ctx, name, ssn, bankTxId) {
        let rechargeCoins = 0;
        switch (bankTxId) {
            case "upg100":
                rechargeCoins = 100;
                break;
            case "upg500":
                rechargeCoins = 500;
                break;
            case "upg1000":
                rechargeCoins = 1000;
                break;
            default:
                return "Provided Transaction ID. is invalid. use upg100, upg500 or upg1000,";
        }
        // createCompositeKey to create unique record map 
        const userKey = ctx.stub.createCompositeKey('regnet.user', [name, ssn]);
        const userBuffer = await ctx.stub.getState(userKey);

        if (userBuffer) {
            let userJSON = JSON.parse(userBuffer.toString());
            userJSON.upgradCoins = userJSON.upgradCoins + rechargeCoins;
            // update user balance
            await ctx.stub.putState(userKey, Buffer.from(JSON.stringify(userJSON)));

            return userJSON;
        } else {
            return "User with key=" + userKey + " does not exist"
        }
    }


    // Initiator: It will be the user. 
    // Output: A ‘Request’ asset on the ledger will be the output. 
    // Use case: A user should call this function to register the details of their property
    //  on the property-registration-network.    
    async propertyRegistrationRequest(ctx, propertyId, price, userName, userSSN) {
        const userKey = ctx.stub.createCompositeKey('regnet.user', [userName, userSSN]);
        const userBuffer = await ctx.stub.getState(userKey);

        if (userBuffer) {
            // createCompositeKey to create unique record map 
            const propertyRequestKey = ctx.stub.createCompositeKey('regnet.request', [propertyId]);
            const propertyRequestObject = {
                docType: 'request',
                propertyId: propertyId,
                owner: userKey,
                price: price,
                status: 'registration requested',
                createdAt: ctx.stub.getTxTimestamp()
            }
            //  update property data
            await ctx.stub.putState(propertyRequestKey, Buffer.from(JSON.stringify(propertyRequestObject)));

            return propertyRequestObject;
        } else {
            return 'Provided Onwer does not exist in the network';
        }
    }

    // Initiator: It will be either the user or registrar.
    // Use case: This function should be defined to view the current state of any property registered 
    // on the ledger.   
    async viewProperty(ctx, propertyId) {
        // createCompositeKey to find property 
        const propertyKey = ctx.stub.createCompositeKey('regnet.property', [propertyId]);
        const propertyBuffer = await ctx.stub.getState(propertyKey);
        //  get property data 
        if (propertyBuffer) {
            return JSON.parse(propertyBuffer.toString());
        } else {
            return "property with key =" + propertyKey + " does not exist"
        }
    }

    // Initiator: It will be a registered user who has their property registered on the ledger. 
    // Use case: This function is invoked to change a property’s status.     
    async updateProperty(ctx, propertyId, propertyStatus, userName, userSSN) {
        const userKey = ctx.stub.createCompositeKey('regnet.user', [userName, userSSN]);
        const propertyKey = ctx.stub.createCompositeKey('regnet.property', [propertyId]);
        // fetch the property data
        const propertyBuffer = await ctx.stub.getState(propertyKey);
        if (propertyBuffer) {
            let propertyJSON = JSON.parse(propertyBuffer.toString());
            if (propertyJSON.owner === userKey) {
                propertyJSON.status = propertyStatus;
                // update property data
                await ctx.stub.putState(propertyKey, Buffer.from(JSON.stringify(propertyJSON)));

                return propertyJSON;
            } else {
                return "Property =" + propertyId+" does not belong to user ="+userName
            }
        } else {
            return "Property =" + propertyId+" does not Exists!"
        }
    }


    // Initiator: It will be a user registered on the network.
    // Use case: In this transaction, a user registered on the network can purchase the properties 
    // that are listed for sale.
    async purchaseProperty(ctx, propertyId, buyerName, buyerSSN) {
        // get property details
        const propertyKey = ctx.stub.createCompositeKey('regnet.property', [propertyId]);
        const propertyBuffer = await ctx.stub.getState(propertyKey);
        // get buyer data
        const buyerKey = ctx.stub.createCompositeKey('regnet.user', [buyerName, buyerSSN]);
        const buyerBuffer = await ctx.stub.getState(buyerKey);

        if (propertyBuffer && buyerBuffer) {
            let propertyJSON = JSON.parse(propertyBuffer.toString());
            // check if property is on sale
            if (propertyJSON.status === 'onSale') {
                let buyerJSON = JSON.parse(buyerBuffer.toString());
                if (buyerJSON.status != "approved"){
                    return 'you are not a approved user'
                }
                // check if buyer has sufficient balance (upgradCoins)
                if (propertyJSON.price <= buyerJSON.upgradCoins) {
                    const originalOwnerKey = propertyJSON.owner;
                    const originalOwnerBuffer = await ctx.stub.getState(originalOwnerKey);

                    if (originalOwnerBuffer) {
                        let propertyPrice = parseInt(propertyJSON.price);

                        propertyJSON.owner = buyerKey;
                        propertyJSON.status = 'registered';
                        await ctx.stub.putState(propertyKey, Buffer.from(JSON.stringify(propertyJSON)));

                        buyerJSON.upgradCoins -= propertyPrice;
                        await ctx.stub.putState(buyerKey, Buffer.from(JSON.stringify(buyerJSON)));

                        let originalOwnerJSON = JSON.parse(originalOwnerBuffer.toString());
                        originalOwnerJSON.upgradCoins += propertyPrice;
                        await ctx.stub.putState(originalOwnerKey, Buffer.from(JSON.stringify(originalOwnerJSON)));

                        return propertyJSON;
                    } else {
                        return 'Owner is not available on the network'
                    }
                } else {
                    return 'Inufficient buyer upgradCoins balance.'
                }
            } else {
                return 'Property is not on sale.'
            }
        } else {
            return 'Invalid Data - property or buyer is noe valid';
        }
    }
}

// export to utilize this file's functionality
module.exports = UserContract;