'use strict';

const { Contract } = require('fabric-contract-api');

class RegistrarContract extends Contract {
    constructor() {
        //name of this smart contract
        super('regnet.registrar');
    }

    async instantiate(ctx) {
        console.log("The RegistrarContract is deployed suuccessfully.");
    }

    // Initiator: It will be the registrar. 
    // Output: A ‘User’ asset on the ledger will be the output. 
    // Use case: The registrar initiates a transaction to register a 
    // new user on the ledger based on the request received.     
    async approveNewUser(ctx, name, socialSecurityNumber) {
        // create user key to search for the user
        const requestedUserKey = ctx.stub.createCompositeKey('regnet.requested', [name, socialSecurityNumber]);
        const requestedUserBuffer = await ctx.stub.getState(requestedUserKey);

        // if user is in DB approve user
        if (requestedUserBuffer) {
            const requestedUserJSON = JSON.parse(requestedUserBuffer.toString());

            const userKey = ctx.stub.createCompositeKey('regnet.user', [name, socialSecurityNumber]);
            const userObject = {
                docType: 'user',
                name: name,
                socialSecurityNumber: socialSecurityNumber,
                emailId: requestedUserJSON.emailId,
                phoneNumber: requestedUserJSON.phoneNumber,
                upgradCoins: 0,
                status: "approved"
            }
            // update user's data
            await ctx.stub.putState(userKey, Buffer.from(JSON.stringify(userObject)));
            return userObject;
        } else {
            return 'There is no request for user with key =' + requestedUserKey + '. Unable process the request.';
        }
    }

    // Initiator: It will be either the user or the registrar. 
    // Use case: This function should be defined to view the current state of any user.
    async viewUser(ctx, name, ssn) {
        // create composite key to fetch user's data
        const userKey = ctx.stub.createCompositeKey('regnet.user', [name, ssn]);
        // get the users data with composite key
        const userBuffer = await ctx.stub.getState(userKey);

        if (userBuffer) {
            return JSON.parse(userBuffer.toString());
        } else {
            return "User with Key" + userKey + " does not exist. Unable view the user."
        }
    }


    // Initiator: It will be the registrar.
    // Output: A ‘Property’ asset on the ledger will be the output. 
    // Use case: The registrar uses this function to create a new “Property” asset on the network after performing certain
    //  manual checks on the request received for property registration.    
    async approvePropertyRegistration(ctx, propertyId) {
        // get property details
        const propertyRequestKey = ctx.stub.createCompositeKey('regnet.request', [propertyId]);
        const propertyRequestedBuffer = await ctx.stub.getState(propertyRequestKey);
        // if property is valid approve the property
        if (propertyRequestedBuffer) {
            const requestJSON = JSON.parse(propertyRequestedBuffer.toString());

            const propertyKey = ctx.stub.createCompositeKey('regnet.property', [propertyId]);
            const propertyObject = {
                docType: "property",
                propertyId: propertyId,
                owner: requestJSON.owner,
                price: requestJSON.price,
                status: "registered",
                createdAt: ctx.stub.getTxTimestamp()
            }

            await ctx.stub.putState(propertyKey, Buffer.from(JSON.stringify(propertyObject)));
            return propertyObject;
        } else {
            return 'Property  ' + propertyRequestKey + 'Not available';
        }
    }

    // Initiator: It will be either the user or registrar.
    // Use case: This function should be defined to view the current state of any property registered 
    // on the ledger.        
    async viewProperty(ctx, propertyId) {
        // view property with composite key
        const propertyKey = ctx.stub.createCompositeKey('regnet.property', [propertyId]);
        const propertyBuffer = await ctx.stub.getState(propertyKey);

        if (propertyBuffer) {
            return JSON.parse(propertyBuffer.toString());
        } else {
            return "property with key =" + propertyKey + " does not exist"
        }
    }
}

// export to utilize this file's functionality
module.exports = RegistrarContract;

