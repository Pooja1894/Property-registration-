'use strict';

const userContract = require('./userContract.js');
const registrarContract = require('./registrarContract.js');
module.exports.contracts = [userContract, registrarContract];
